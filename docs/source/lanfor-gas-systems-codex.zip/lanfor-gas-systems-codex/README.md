# Lanfor Gas Systems — Codex-ready seed

Separate B2B website for process-gas compression, boosting and oil-free functional modules.

## Start
```bash
cp .env.example .env.local
npm install
npm run dev
```

## Read before changing the project
1. `AGENTS.md`
2. `docs/MASTER_SPEC.md`
3. `docs/AUDIT_AND_DECISIONS.md`
4. `docs/CONTENT_MODEL.md`
5. `docs/SEO_AI.md`
6. `docs/CODEX_PROMPT.md`

## Important
Seed product-family data from the supplied UNIGY 2026 catalogue is intentionally marked `draft`. It is a source envelope, not a guaranteed operating point. Verify before public production use.

## Current implementation
- Next.js 16.4 / App Router / TypeScript
- server-rendered content pages
- responsive technical design system
- task/gas/equipment entity navigation
- 5-parameter RFQ wizard
- Product JSON-LD
- robots + sitemap + optional llms.txt
- content / analytics / image / migration specs

## Production integrations still intentionally not connected
- CMS (Directus/PostgreSQL adapter)
- CRM webhook
- file storage + signed URLs
- Yandex Metrika / GA4 IDs
- real approved visual assets
- verified product records and documents
