Place approved/generated production images here following docs/IMAGE_PLAN.md.
Do not ship third-party catalogue images unless Lanfor has the right to publish them.
