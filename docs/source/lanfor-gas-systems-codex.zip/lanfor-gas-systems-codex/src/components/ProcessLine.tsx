export function ProcessLine({ items }: { items: string[] }) {
  return (
    <ol className="process-line">
      {items.map((item, i) => <li key={item}><span>{String(i + 1).padStart(2, "0")}</span><b>{item}</b></li>)}
    </ol>
  );
}
