import Link from "next/link";
import { site } from "@/content/site";

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <div className="brand brand-footer"><span className="brand-mark">L</span><span><b>LANFOR</b><small>GAS SYSTEMS</small></span></div>
          <p className="muted">Инженерные системы сжатия, дожатия и возврата технологических газов.</p>
        </div>
        <div><b>Навигация</b><Link href="/solutions">Решения</Link><Link href="/equipment">Оборудование</Link><Link href="/engineering">Инженерам</Link></div>
        <div><b>Контакты</b><a href={`tel:${site.phone.replace(/[^+\d]/g,"")}`}>{site.phone}</a><a href={`mailto:${site.email}`}>{site.email}</a></div>
        <div><b>Запрос</b><Link href="/rfq">Отправить рабочую точку</Link><Link href="/documents">Документы и CAD</Link></div>
      </div>
      <div className="container legal">Технические параметры конкретного исполнения подтверждаются в ТКП и документации проекта.</div>
    </footer>
  );
}
