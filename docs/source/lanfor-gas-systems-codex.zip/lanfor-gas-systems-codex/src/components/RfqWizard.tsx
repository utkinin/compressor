"use client";

import { useMemo, useState } from "react";

const gasOptions = ["N₂ / азот", "He / гелий", "H₂ / водород", "CO₂", "O₂ / кислород", "SF₆", "Другой газ / смесь"];
const dutyOptions = ["Непрерывный", "Периодический", "Циклический", "Не знаю — нужен разбор"];

export function RfqWizard({ compact = false }: { compact?: boolean }) {
  const [form, setForm] = useState({ gas: "", p1: "", p2: "", q: "", duty: "", note: "" });
  const [copied, setCopied] = useState(false);
  const update = (key: keyof typeof form, value: string) => setForm((x) => ({ ...x, [key]: value }));
  const complete = form.gas && form.p1 && form.p2 && form.q && form.duty;

  const text = useMemo(() => [
    "Запрос на предварительный подбор компрессорного решения",
    `Газ: ${form.gas || "—"}`,
    `P₁ на входе: ${form.p1 || "—"}`,
    `P₂ на выходе: ${form.p2 || "—"}`,
    `Расход Q: ${form.q || "—"}`,
    `Режим: ${form.duty || "—"}`,
    form.note ? `Комментарий: ${form.note}` : ""
  ].filter(Boolean).join("\n"), [form]);

  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  }

  return (
    <div className={`rfq-card ${compact ? "rfq-compact" : ""}`}>
      <div className="section-kicker">Рабочая точка</div>
      <h2>{compact ? "5 параметров для предварительного подбора" : "Сформируйте инженерный запрос"}</h2>
      <p className="muted">Не нужно знать модель компрессора. Достаточно исходных условий процесса.</p>
      <div className="rfq-grid">
        <label><span>1. Газ</span><select value={form.gas} onChange={e => update("gas", e.target.value)}><option value="">Выберите среду</option>{gasOptions.map(x => <option key={x}>{x}</option>)}</select></label>
        <label><span>2. P₁ на входе</span><input value={form.p1} onChange={e => update("p1", e.target.value)} placeholder="например, 5 bar(g)" /></label>
        <label><span>3. P₂ на выходе</span><input value={form.p2} onChange={e => update("p2", e.target.value)} placeholder="например, 25 bar(g)" /></label>
        <label><span>4. Расход Q</span><input value={form.q} onChange={e => update("q", e.target.value)} placeholder="например, 60 Nm³/h" /></label>
        <label><span>5. Режим работы</span><select value={form.duty} onChange={e => update("duty", e.target.value)}><option value="">Выберите режим</option>{dutyOptions.map(x => <option key={x}>{x}</option>)}</select></label>
        {!compact && <label className="span-2"><span>Комментарий / процесс / ограничения</span><textarea value={form.note} onChange={e => update("note", e.target.value)} placeholder="Источник газа, чистота, температура, Ex-зона, буфер, ограничения по размещению…" /></label>}
      </div>
      <div className="rfq-output"><pre>{text}</pre></div>
      <div className="actions"><button className="button" onClick={copy} disabled={!complete}>{copied ? "Скопировано" : "Скопировать запрос"}</button><a className="button button-ghost" href={`mailto:info@sf6rus.ru?subject=${encodeURIComponent("Подбор компрессорного решения")}&body=${encodeURIComponent(text)}`}>Отправить инженеру</a></div>
    </div>
  );
}
