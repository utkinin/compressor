import Link from "next/link";
import { site } from "@/content/site";

export function Header() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link href="/" className="brand" aria-label={site.name}>
          <span className="brand-mark">L</span>
          <span><b>LANFOR</b><small>GAS SYSTEMS</small></span>
        </Link>
        <nav className="main-nav" aria-label="Главная навигация">
          <Link href="/solutions">Решения</Link>
          <Link href="/equipment">Оборудование</Link>
          <Link href="/engineering">Инженерам</Link>
          <Link href="/knowledge">База знаний</Link>
          <Link href="/about">О направлении</Link>
        </nav>
        <Link href="/rfq" className="button button-sm">Подобрать по 5 параметрам</Link>
      </div>
    </header>
  );
}
