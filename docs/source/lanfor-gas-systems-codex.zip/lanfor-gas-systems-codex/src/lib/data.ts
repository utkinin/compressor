import { gases } from "@/content/gases";
import { productFamilies } from "@/content/products";
import { solutions } from "@/content/solutions";

export const getGas = (slug: string) => gases.find((x) => x.slug === slug);
export const getProduct = (slug: string) => productFamilies.find((x) => x.slug === slug);
export const getSolution = (slug: string) => solutions.find((x) => x.slug === slug);

export { gases, productFamilies, solutions };
