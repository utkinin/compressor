import type { ProductFamily } from "@/lib/types";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.ru";

export function productJsonLd(product: ProductFamily) {
  const properties = [
    product.inletPressureMpaMax != null && { "@type": "PropertyValue", name: "Максимальное входное давление", value: product.inletPressureMpaMax, unitText: "MPa" },
    product.dischargePressureMpaMax != null && { "@type": "PropertyValue", name: "Максимальное давление нагнетания", value: product.dischargePressureMpaMax, unitText: "MPa" },
    product.flowNm3hMin != null && { "@type": "PropertyValue", name: "Минимальная теоретическая производительность", value: product.flowNm3hMin, unitText: "Nm³/h" },
    product.flowNm3hMax != null && { "@type": "PropertyValue", name: "Максимальная теоретическая производительность", value: product.flowNm3hMax, unitText: "Nm³/h" },
    product.motorKwMin != null && { "@type": "PropertyValue", name: "Минимальная мощность двигателя", value: product.motorKwMin, unitText: "kW" },
    product.motorKwMax != null && { "@type": "PropertyValue", name: "Максимальная мощность двигателя", value: product.motorKwMax, unitText: "kW" },
    product.tightnessMbarLs != null && { "@type": "PropertyValue", name: "Заявленная газоплотность", value: product.tightnessMbarLs, unitText: "mbar·l/s" }
  ].filter(Boolean);

  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "@id": `${siteUrl}/equipment/${product.slug}#product`,
    name: product.name,
    description: product.short,
    brand: { "@type": "Brand", name: "UNIGY / Lanfor Gas Systems" },
    category: "Industrial gas compressor",
    url: `${siteUrl}/equipment/${product.slug}`,
    additionalProperty: properties
  };
}
