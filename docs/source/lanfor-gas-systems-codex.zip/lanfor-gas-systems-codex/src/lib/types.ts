export type VerificationStatus = "verified" | "draft" | "needs-review";

export type Gas = {
  slug: string;
  symbol: string;
  name: string;
  summary: string;
  engineeringNotes: string[];
  applications: string[];
};

export type ProductFamily = {
  slug: string;
  name: string;
  category: "oil-free-reciprocating" | "booster" | "system";
  short: string;
  gases: string[];
  inletPressureMpaMax?: number;
  dischargePressureMpaMax?: number;
  flowNm3hMin?: number;
  flowNm3hMax?: number;
  motorKwMin?: number;
  motorKwMax?: number;
  tightnessMbarLs?: number;
  cooling: string[];
  transmission?: string;
  verificationStatus: VerificationStatus;
  sourceNote: string;
};

export type Solution = {
  slug: string;
  eyebrow: string;
  title: string;
  intro: string;
  pains: string[];
  architecture: string[];
  gases: string[];
  industries: string[];
};
