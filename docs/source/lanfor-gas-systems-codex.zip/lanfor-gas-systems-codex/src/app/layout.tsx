import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { site } from "@/content/site";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.ru";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: `${site.title} | ${site.name}`, template: `%s | ${site.name}` },
  description: site.description,
  alternates: { canonical: "/" },
  openGraph: { title: site.title, description: site.description, type: "website", locale: "ru_RU", siteName: site.name },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body><Header /><main>{children}</main><Footer /></body></html>;
}
