import { notFound } from "next/navigation";
import Link from "next/link";
import { getSolution, solutions } from "@/lib/data";
import { ProcessLine } from "@/components/ProcessLine";
export function generateStaticParams(){return solutions.map(s=>({slug:s.slug}))}
export default async function SolutionPage({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const s=getSolution(slug);if(!s)notFound();return <><section className="section page-top"><div className="container narrow"><div className="eyebrow">{s.eyebrow}</div><h1>{s.title}</h1><p className="page-lead">{s.intro}</p><div className="actions"><Link className="button" href="/rfq">Отправить рабочую точку</Link><Link className="button button-ghost" href="/engineering">Как проходит подбор</Link></div></div></section><section className="section section-dark"><div className="container split"><div><div className="section-kicker">Типовые ограничения</div><h2>Что обычно приводит к запросу</h2><ul className="check-list">{s.pains.map(x=><li key={x}>{x}</li>)}</ul></div><ProcessLine items={s.architecture}/></div></section></>}
