import { notFound } from "next/navigation";
import Link from "next/link";
import { getProduct, productFamilies } from "@/lib/data";
import { JsonLd } from "@/components/JsonLd";
import { productJsonLd } from "@/lib/jsonld";

export function generateStaticParams() { return productFamilies.map(p => ({ slug: p.slug })); }

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = getProduct(slug);
  if (!p) notFound();
  return <><JsonLd data={productJsonLd(p)} /><section className="section page-top"><div className="container product-hero"><div><div className="eyebrow">Oil-free compressor family</div><h1>{p.name}</h1><p className="page-lead">{p.short}</p><div className="notice">Статус данных: <b>{p.verificationStatus}</b>. Диапазоны относятся к семейству и не являются подтверждением конкретной рабочей точки.</div><div className="actions"><Link className="button" href={`/rfq?series=${p.slug}`}>Проверить рабочую точку</Link><Link className="button button-ghost" href="/documents">Документы</Link></div></div><div className="spec-panel"><div><small>Max P₁</small><b>{p.inletPressureMpaMax} MPa</b></div><div><small>Max P₂</small><b>{p.dischargePressureMpaMax} MPa</b></div><div><small>Flow envelope</small><b>{p.flowNm3hMin}–{p.flowNm3hMax} Nm³/h</b></div><div><small>Motor</small><b>{p.motorKwMin}–{p.motorKwMax} kW</b></div></div></div></section><section className="section section-soft"><div className="container"><div className="section-head"><div><div className="section-kicker">Технические данные</div><h2>Параметры семейства</h2></div><p>В HTML, а не только в PDF: это важно и инженеру, и поисковым системам.</p></div><table className="tech-table"><tbody><tr><th>Среды из каталога</th><td>{p.gases.join(", ")}</td></tr><tr><th>Максимальное входное давление</th><td>{p.inletPressureMpaMax} MPa</td></tr><tr><th>Максимальное давление нагнетания</th><td>{p.dischargePressureMpaMax} MPa</td></tr><tr><th>Теоретический расход</th><td>{p.flowNm3hMin}–{p.flowNm3hMax} Nm³/h</td></tr><tr><th>Мощность двигателя</th><td>{p.motorKwMin}–{p.motorKwMax} kW</td></tr><tr><th>Заявленная газоплотность</th><td>{p.tightnessMbarLs} mbar·l/s</td></tr><tr><th>Охлаждение</th><td>{p.cooling.join(" / ")}</td></tr><tr><th>Привод</th><td>{p.transmission}</td></tr></tbody></table><p className="source-note">Источник: {p.sourceNote}</p></div></section></>;
}
