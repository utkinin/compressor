import Link from "next/link";
import { productFamilies } from "@/lib/data";

export const metadata = { title: "Безмасляные компрессоры и бустеры" };

export default function EquipmentPage() {
  return <section className="section page-top"><div className="container"><div className="eyebrow">Оборудование</div><h1>Безмасляные компрессорные платформы</h1><p className="page-lead">Сравнивайте диапазоны только как предварительную карту. Конкретное исполнение определяется рабочей точкой, газом, температурой, режимом и требованиями процесса.</p><div className="cards three">{productFamilies.map(p => <Link key={p.slug} href={`/equipment/${p.slug}`} className="product-card"><div className="status">{p.verificationStatus}</div><h2>{p.name}</h2><p>{p.short}</p><dl><div><dt>P₂ max</dt><dd>{p.dischargePressureMpaMax} MPa</dd></div><div><dt>Q</dt><dd>{p.flowNm3hMin}–{p.flowNm3hMax} Nm³/h</dd></div><div><dt>Motor</dt><dd>{p.motorKwMin}–{p.motorKwMax} kW</dd></div></dl><span className="arrow">Техническая страница →</span></Link>)}</div></div></section>;
}
