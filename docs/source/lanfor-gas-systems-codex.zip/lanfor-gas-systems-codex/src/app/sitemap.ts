import type { MetadataRoute } from "next";
import { gases, productFamilies, solutions } from "@/lib/data";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://example.ru";
  const staticRoutes = ["", "/solutions", "/equipment", "/engineering", "/documents", "/knowledge", "/rfq", "/about"];
  return [
    ...staticRoutes.map((path) => ({ url: `${base}${path}`, changeFrequency: "weekly" as const, priority: path === "" ? 1 : 0.7 })),
    ...gases.map((g) => ({ url: `${base}/gases/${g.slug}`, changeFrequency: "monthly" as const, priority: 0.8 })),
    ...solutions.map((s) => ({ url: `${base}/solutions/${s.slug}`, changeFrequency: "monthly" as const, priority: 0.9 })),
    ...productFamilies.map((p) => ({ url: `${base}/equipment/${p.slug}`, changeFrequency: "monthly" as const, priority: 0.9 })),
  ];
}
