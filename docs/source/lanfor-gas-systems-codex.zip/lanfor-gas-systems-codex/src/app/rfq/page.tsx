import { RfqWizard } from "@/components/RfqWizard";
export const metadata = { title: "Подбор компрессора по рабочей точке" };
export default function RfqPage(){return <section className="section page-top"><div className="container narrow"><div className="eyebrow">RFQ / Engineering intake</div><h1>Подбор по пяти исходным параметрам</h1><p className="page-lead">Это первичный инженерный фильтр, а не автоматический расчёт компрессора. Он формирует нормальный запрос без длинного опросного листа.</p><RfqWizard /></div></section>}
