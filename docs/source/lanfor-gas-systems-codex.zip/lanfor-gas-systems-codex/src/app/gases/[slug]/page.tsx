import { notFound } from "next/navigation";
import Link from "next/link";
import { gases, getGas } from "@/lib/data";
export function generateStaticParams(){return gases.map(g=>({slug:g.slug}))}
export default async function GasPage({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const g=getGas(slug);if(!g)notFound();return <section className="section page-top"><div className="container gas-detail"><div className="gas-symbol">{g.symbol}</div><div><div className="eyebrow">Технологический газ</div><h1>Компрессорные решения для {g.name.toLowerCase()}</h1><p className="page-lead">{g.summary}</p><h2>Что проверяем при подборе</h2><ul className="check-list light">{g.engineeringNotes.map(x=><li key={x}>{x}</li>)}</ul><h2>Типовые применения</h2><div className="tags">{g.applications.map(x=><span key={x}>{x}</span>)}</div><div className="actions"><Link className="button" href={`/rfq?gas=${g.slug}`}>Подобрать решение</Link></div></div></div></section>}
