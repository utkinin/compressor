import Link from "next/link";
import { gases, productFamilies, solutions } from "@/lib/data";
import { RfqWizard } from "@/components/RfqWizard";
import { ProcessLine } from "@/components/ProcessLine";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <div className="eyebrow">PROCESS GAS / OIL-FREE / BOOSTING / SKID</div>
            <h1>Сжимаем технологический газ под рабочую точку процесса.</h1>
            <p className="hero-lead">Безмасляные компрессоры, бустеры и функциональные модули для N₂, He, H₂, CO₂ и специальных газов. От отдельной машины до skid-узла с КИП, охлаждением, обвязкой и автоматикой.</p>
            <div className="hero-actions"><Link className="button" href="/rfq">Подобрать по 5 параметрам</Link><Link className="text-link" href="/solutions">Смотреть типовые задачи →</Link></div>
            <div className="proof-row"><span><b>1–500+</b><small>Нм³/ч · семейства</small></span><span><b>до 150+</b><small>бар · по серии</small></span><span><b>Oil-Free</b><small>чистые процессы</small></span></div>
          </div>
          <div className="hero-visual" aria-label="Схема компрессорного технологического контура">
            <div className="grid-lines" />
            <svg viewBox="0 0 720 520" role="img" aria-labelledby="heroDiagramTitle"><title id="heroDiagramTitle">Условная схема газового компрессорного модуля</title>
              <path d="M80 315 H180"/><path d="M435 315 H635"/><rect x="180" y="205" width="255" height="220" rx="18"/><circle cx="250" cy="315" r="47"/><circle cx="365" cy="315" r="47"/><path d="M250 268 V235 H365 V268"/><path d="M250 362 V390 H365 V362"/><circle cx="80" cy="315" r="11"/><circle cx="635" cy="315" r="11"/><path d="M522 270 v90"/><path d="M500 292 h44"/><path d="M500 338 h44"/>
              <text x="180" y="178">COMPRESSOR MODULE</text><text x="45" y="348">P₁ / Q</text><text x="604" y="348">P₂</text><text x="485" y="385">CONTROL</text>
            </svg>
            <div className="hero-caption"><span>Не выбирайте компрессор по названию.</span><b>Выбирайте по газу, P₁, P₂, Q и режиму.</b></div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head"><div><div className="section-kicker">Решения</div><h2>Вход через задачу, а не через каталог</h2></div><p>Для инженера важна схема и рабочая точка. Для закупщика — состав поставки, документы и управляемый риск. Страница должна давать оба слоя сразу.</p></div>
          <div className="cards three">{solutions.map((s, i) => <Link className="solution-card" href={`/solutions/${s.slug}`} key={s.slug}><span className="card-index">0{i+1}</span><div className="eyebrow">{s.eyebrow}</div><h3>{s.title}</h3><p>{s.intro}</p><span className="arrow">Открыть решение →</span></Link>)}</div>
        </div>
      </section>

      <section className="section section-dark">
        <div className="container split">
          <div><div className="section-kicker">Метод</div><h2>Пять исходных данных дают больше, чем длинный каталог.</h2><p className="muted-light">На первом шаге не спрашиваем десятки параметров. Фиксируем рабочую точку и понимаем класс решения. На втором — уточняем чистоту, температуру, охлаждение, Ex, материалы, буфер и автоматику.</p></div>
          <ProcessLine items={["Газ", "P₁ вход", "P₂ выход", "Расход Q", "Режим"]}/>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head"><div><div className="section-kicker">Среды</div><h2>Навигация по технологическому газу</h2></div><Link className="text-link" href="/engineering">Как мы подбираем →</Link></div>
          <div className="gas-grid">{gases.map(g => <Link key={g.slug} href={`/gases/${g.slug}`} className="gas-card"><strong>{g.symbol}</strong><div><h3>{g.name}</h3><p>{g.summary}</p></div></Link>)}</div>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="section-head"><div><div className="section-kicker">Оборудование</div><h2>Семейства платформ, а не ложная точность</h2></div><p>Диапазон семейства — это карта возможностей. Конкретная рабочая точка подтверждается расчётом и ТКП.</p></div>
          <div className="table-wrap"><table className="tech-table"><thead><tr><th>Серия</th><th>P₁ max</th><th>P₂ max</th><th>Q</th><th>Мощность</th><th></th></tr></thead><tbody>{productFamilies.map(p => <tr key={p.slug}><td><b>{p.name}</b><small>{p.verificationStatus === "verified" ? "verified" : "требует верификации"}</small></td><td>{p.inletPressureMpaMax} MPa</td><td>{p.dischargePressureMpaMax} MPa</td><td>{p.flowNm3hMin}–{p.flowNm3hMax} Nm³/h</td><td>{p.motorKwMin}–{p.motorKwMax} kW</td><td><Link href={`/equipment/${p.slug}`}>Открыть →</Link></td></tr>)}</tbody></table></div>
        </div>
      </section>

      <section className="section"><div className="container"><RfqWizard compact /></div></section>
    </>
  );
}
