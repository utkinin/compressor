import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const required = ["gas", "p1", "p2", "q", "duty"];
  const missing = required.filter((k) => !body?.[k]);
  if (missing.length) return NextResponse.json({ ok: false, error: "missing_fields", missing }, { status: 400 });
  // TODO: send to CRM/webhook. Never log secrets or attachments in plaintext server logs.
  return NextResponse.json({ ok: true, id: crypto.randomUUID() });
}
